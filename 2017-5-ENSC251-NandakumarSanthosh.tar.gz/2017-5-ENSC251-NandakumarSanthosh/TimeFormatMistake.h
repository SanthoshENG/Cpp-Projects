#ifndef TIMEFORMATMISTAKES_H
#define TIMEFORMATMISTAKES_H

#include <iostream>
#include <string>

using namespace std;
/*
* The class TimeFormatMistakes holds all the cases
* of mistakes that were made by the user while inputing a 24-hour time
*/
class TimeFormatMistake
{
	public:

		//Default Constructor for class TimeFormatMistake
		TimeFormatMistake();

		//Constructor called when a string is thrown
		//Sets the value that was entered for the time
		//into the private variable string wrongTime24
		TimeFormatMistake(string wtime);

		//Constructor called when the improper time divider
		//(not a colon) is entered
		//This incorrect character is also stored in private variable
		//char timeDivider
		TimeFormatMistake(char notColon);


		//Constructor called when an inappropriate value
		//of the time is entered. Ex: 25:56, the value of 25 hours is invalid.
		//These incorrect values for the time are stored in private variables
		//int wrongHour and int wrongMinute respectively.
		TimeFormatMistake(int hoursVal, int minutesVal);

	private:
		string wrongTime24;
		int wrongHour;
		int wrongMinute;
		char timeDivider;


};

#endif
