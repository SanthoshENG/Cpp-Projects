#include <iostream>
#include <string>
#include "TimeFormatMistake.h"
using namespace std;



TimeFormatMistake::TimeFormatMistake()
{

}
TimeFormatMistake::TimeFormatMistake(string wtime)
{
	    wrongTime24 = wtime;
}
TimeFormatMistake::TimeFormatMistake(char notColon)
{
		timeDivider = notColon;
}
TimeFormatMistake::TimeFormatMistake(int hoursVal, int minutesVal)
{
		wrongHour = hoursVal;
		wrongMinute = minutesVal;
}


