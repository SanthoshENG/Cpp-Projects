

/**
* @file <lab5>.cpp
* @author <SANTHOSH> <NANDAKUMAR>
* @student# <301300261>
* @date <NOVEMBER 3, 2017>
* @version <1>
*
* @brief <ENSC 251, Lab 5>
*
* @section DESCRIPTION
*
* This code converts a user input of 24-hour time into 12-hour time,
* It also checks for errors in the input using try, throw and catch.
*/

/*
* The class TimeFormatMistakes holds all the cases
* of mistakes that were made by the user while inputing a 24-hour time
*/

#include <iostream>
#include <string.h>
#include <sstream>
#include <string>
#include "TimeFormatMistake.h"
#include "TimeFormatMistake.cpp"

using namespace std;



/**
* @brief This function removes the colon from the string time
* @preCondition: best if the string is 5 characters long
* @param: time24 is the string to be changed
* @postCondition: the string no longer contains a colon
* The string may now be converted to an integer using Time2Int
* @return: string
*/
string removeColon(string time24);

/**
* @brief: This function converts the time from a
* string into an integer
* @preCondition: the input variable must be of type
* string containing numbers otherwise zero will be
* returned triggering an error
* @param: changeString is the time string to be changed
* @postCondition: the string is converted to an integer
* @return: int
*/
int Time2Int( string changeString );


/**
* @brief: This function converts 24 hour time into 12 hour time
* @preCondition: the hour value and minutes value extracted from
* 24 hour time are valid integers between 0-23 for hours and
* 0-59 for minutes
* @param: hours of type int which are in range
* @param: minutes of type int which are in range
* @postCondition: the 24 hour time is displayed as a 12 hour time
* @return: string
*/
string time24To12(int hours, int minutes);



int main()
{

string time24;
string tempTime;
string shours = "00";
string sminutes = "00";
int ihours;
int iminutes;
char response ='y';


/*do-while loop that allows user to keep entering 24 hour times
*loop checks for errors using exception handling
*try, throw statements and catch blocks are used to check for errors
*/

do
{

 try{
	cout << "Enter time in 24-hour notation: " << endl;
    cin >> time24;

    if (time24.size() != 5)
    	throw time24;

    //checks if third element in the string is a colon
    if (time24[2] != ':')
    	throw time24[2];

    tempTime = removeColon(time24);

    //splits up the string according hours and minutes
    shours[0] = tempTime[0];
    shours[1] = tempTime[1];
    sminutes[0] = tempTime[2];
    sminutes[1] = tempTime[3];

    //converts the strings of hours and minutes in into integers
    ihours = Time2Int(shours);
    iminutes = Time2Int(sminutes);


    if (ihours > 23 || ihours < 0 || iminutes > 59 || iminutes <0)

    	throw TimeFormatMistake(ihours, iminutes);

    cout << "That is the same as " << time24To12(ihours,iminutes) << endl;


    cout << "Again?(y/n)" << endl;
    cin >> response;

    if (response == 'n' || response == 'N')
    {
        cout << "End of Program" << endl;
        break;

    }
    else if (response != 'y'&& response != 'Y')
    {
    	   cout << "Invalid Input, Ending program" << endl;
    	   break;
    }

}
catch(string wtime)
{
        cout << "Error: improper string length was entered, other invalidities may exists."<< endl;
        cout << "A 24-hour time was not entered " << endl;
        cout << "Try Again:" << endl;
        continue;
}
catch(char notColon)
{
        cout << "Error: improper character were entered."<<endl;
        cout << "A 24-hour time was not entered " << endl;
        cout << "Try Again:" << endl;
        continue;
}

catch(TimeFormatMistake& time)
{

        cout << "There is no such time as "<< time24 << endl;
        cout << "Try Again:" << endl;
        continue;
}
catch(...)
{
        cout << "Other Error" << endl;
        continue;

}

}while( response == 'y' || response == 'Y');

return 0;

}

int Time2Int( string changeString )
{

	string stringToInteger(changeString);
	stringstream str(stringToInteger);
	int x;
	str >> x;

	return x;
}

string removeColon(string time24)
{
	string myString = "00000" ;

		  string actual_Time = "0000";

		  actual_Time[0]=time24[0];
		  actual_Time[1]=time24[1];
		  actual_Time[2]=time24[3];
		  actual_Time[3]=time24[4];

		  myString = actual_Time ;

		  return myString;

}

string time24To12(int hours, int minutes)
{


    int newHours;
    string finalTime;
    string minutes12;
    if(hours > 12)
    {
        newHours = hours - 12;
        stringstream sh;
        stringstream mh;
        sh << newHours;
        mh << minutes;
        string hours12 = sh.str();
        if(minutes<10)
        {
            minutes12 = "0" + mh.str();
        }
        else
        {
            minutes12 = mh.str();
        }

        finalTime = hours12 + ":" + minutes12 + "PM";



    }
    else if(hours == 12)
    {
        newHours = hours;
        stringstream sh;
        stringstream mh;
        sh << newHours;
        mh << minutes;
        string hours12 = sh.str();

        if(minutes<10)
        {
            minutes12 = "0" + mh.str();
        }
        else
        {
            minutes12 = mh.str();
        }

        finalTime = hours12 +":"+ minutes12 + "PM";
    }
    else if(hours == 0)
    {
       string hours12 = "12";
       stringstream mh;
       mh << minutes;
        if(minutes<10)
        {
            minutes12 = "0" + mh.str();
        }
        else
        {
            minutes12 = mh.str();
        }

        finalTime = hours12 +":"+ minutes12 + "AM";

    }


    else
    {
        newHours = hours;
        stringstream sh;
        stringstream mh;
        sh << newHours;
        mh << minutes;
        string hours12 = sh.str();

        if(minutes<10)
        {
            minutes12 = "0" + mh.str();
        }
        else
        {
            minutes12 = mh.str();
        }


        finalTime = hours12 + ":" + minutes12 + "AM";

    }

    return finalTime;
}



