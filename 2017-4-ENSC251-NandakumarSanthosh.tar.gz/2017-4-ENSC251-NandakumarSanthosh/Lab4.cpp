// I declare that this assignment is my own work and that I have correctly acknowledged the
// work of others. I acknowledged that I have read and followed the Academic Honesty and
// Integrity related policies as outlined in the syllabus.
//
// Santhosh Nandakumar    October 6, 2017
//
// 301300261


#include <iostream>
#include <string>
using namespace std;




//Describes one element in the Linked list
class Node
  {
    public:

		// @brief Constructor intializes name to "0" and pointer to NULL
		Node( );

		/*@brief Constructor to intialize the node to specified value
		* @param string myName - The name to be stored in the private variable name in class
		*        Node *next - pointer to the next node in the Linked list
		*
		* @return None
		*/

		Node(string myName, Node *next);

		/*@brief Accessor function which accesses the private member variable, name
		*        retrieves the value in the node
		* @param None
		* @return string
		*/

		string getName( ) const;


		/*@brief Accessor function which accesses the private member variable' link
		*        retrieves the pointer to the next node
		* @param None
		* @return pointer to the next node
		*/

		Node *getLink( ) const;

		/*@brief sets the name which is stored in the node
		* @param string myName - The name stored in the private variable name in class
		*
		*
		* @return void
		*/

		void setName(string myName);

		/*@brief sets the link which points to the next node
		* @param Node *next - takes in the pointer which points to the next node and stores in current node
		*
		*
		* @return void
		*/

		void setLink(Node *next);

		/*@brief prints the list
		* @param Node *tempPtr loops the pointer through the list
		* 		               till the whole list is printed and tempPtr points to NULL
		*
		*
		* @return void
		*/


		void printList(Node *tempPtr);

    private:
		//stores name as a string
		string name;

		//stores the pointer to the next node
		Node *link;
  };
  typedef Node* NodePtr;

/*@brief Inserts a new node at the beginning of the linked list
* @param NodePtr &head - pass head by reference to move the header to the top of the list
*        string theName the name that is stored in the new node
*
* @return void
*/

void insertHead(NodePtr &head, string theName);

/*@brief Inserts a new node in the middle of the linked list
* @param NodePtr afterNode - the pointer afterNode that will be stored in the new node
* 							 afterNode will now point to the new node
*        string theName the name that is stored in the new node
*
* @return void
*/

void insertNode(NodePtr afterNode, string theName);



int main()
{
	NodePtr head, tempPtr, tempToDelete;

	// Creates the original list

		head = new Node( "Joules", NULL);
		insertHead(head, "James");
		insertHead(head, "Emily");
		//removeNode(head,"Joules");


	tempPtr = head;

	cout << "The original list is:" << endl;

	// Prints the original list
	tempPtr->printList(tempPtr);

	//inserts the name Joshua in the list
	insertNode(head->getLink(), "Joshua");

	cout << endl << "The list containing Joshua is:" << endl;

	//Prints updated list
	head->printList(head);

	head->getLink()->getLink()-> setLink(NULL);

	//deletes Joules from the list
	tempToDelete = head-> getLink()-> getLink()-> getLink();
	delete tempToDelete;

	cout << endl << "The list after Joules has been removed is:" << endl;

	//Prints the new list without Joules
	head->printList(head);

	tempPtr = head;

	//Loop that deletes all elements in the list
	while (tempPtr != NULL)
	{
		NodePtr nodeToDelete = tempPtr;
		tempPtr = tempPtr->getLink();
		delete nodeToDelete;
	}

	return 0;
}



	Node::Node( )
	{
		name = "0";
		link = NULL;
	}

	Node::Node(string myName, Node *next)
	{
		name = myName;
		link = next;
	}


	string Node::getName( ) const
	{
	    return name;
	}

	Node* Node::getLink( ) const
	{
	    return link;
	}

	void Node::setName(string myName)
	{
	    name = myName;
	}

	void Node::setLink(Node *next)
	{
	link = next;
	}
	void Node::printList(Node *tempPtr)
	{

		while (tempPtr != NULL)
		{
			cout << tempPtr-> name << endl;
			tempPtr = tempPtr-> link;
		}
	}

	void insertHead(NodePtr &head, string theName)
	{
		NodePtr tempPtr;
		tempPtr = new Node(theName, head);
		head = tempPtr;

	}
	void insertNode(NodePtr afterNode, string theName)
	{
		NodePtr tempPtr;
		tempPtr = new Node;
		tempPtr->setName(theName);
		tempPtr->setLink(afterNode->getLink());
		afterNode->setLink(tempPtr);
	}
