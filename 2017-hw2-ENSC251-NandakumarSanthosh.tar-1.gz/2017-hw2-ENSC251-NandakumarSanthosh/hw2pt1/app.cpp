#include <iostream>
#include <cstdlib>
#include <cstddef>
#include <ctime>
#include <vector>
#include "DMV.h"
#include "DMV.cpp"
using namespace std;



int main()
{
    //Initializes and creates a class queue
	DMVQueue q;

	//checks if the q is empty
    q.isEmpty();

    //Does the whole processes of customer arrival to customer being helped
    //to when the program exists if 3 is pressed
    q.processQueue(q);



    return 0;
}


