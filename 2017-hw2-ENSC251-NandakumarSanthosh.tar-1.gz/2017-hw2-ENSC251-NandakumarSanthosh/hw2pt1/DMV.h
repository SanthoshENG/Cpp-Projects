#ifndef DMV_H
#define DMV_H
#include <iostream>
using namespace std;

//structure containing each node in the Queue
struct DMVQueueNode
{
    int customer;
    DMVQueueNode *link;
};

typedef DMVQueueNode* QueueNodePtr;


class DMVQueue
{
    public:

		/*Default constructor
		 * Arguments: none
		 * Intializes the object to an empty queue
		 */
		DMVQueue( );


		/*Copy Constructor
		 * Pre-Condition: object needing to be copied
		 * Arguments: pass by reference but using const to be more efficient object: aQueue
		 * Post Condition: object is copied
		 * Is not used in this application of the class but may be useful in other cases
		 */
        DMVQueue(const DMVQueue& aQueue);

        /*Destructor
         * Pre-Condition: object to be destroyed in this case a Queue
         * Arguments: none
         * Post Condition: object is deleted and memory is deallocated
         */
        ~DMVQueue( );

        /*Calculates the time of arrival and exit in the queue
         * Pre-Condition: need to find the time
  		 * Arguments: None
         * Post Condition: time value data type long is returned
         */
        long timeQueue();

        /*Calculates the wait time of the customer
         * Pre-Condition: time in and time out are provided and are stored in vectors
  		 * Arguments: all pass by value vector<long> timeIn,vector <long> timeOut, int o, int w
  		 * int o and int w extract the values at a particular index of timeIn and timeOut
  		 * Return: long time in seconds(entered or departed)
         * Post Condition: wait time as data type long is returned
         */
        long calcWaitTime(vector <long> timeIn, vector <long> timeOut, int o, int w);

        /*Calculates the average time in the queue for the next customer based
         * on the wait times of the previous three customers
         * Pre-Condition: previous three or fewer average wait times are present
  		 * Arguments: pass by value vector <long> waitTimes
  		 * Return: long calculated wait time
         * Post Condition: average wait time is returned
         */
        long calcAverageTime(vector <long> waitTimes);

        /*Adds a customer to the line via a Queue
         * Pre-Condition: customer number must be of type integer
  		 * Arguments: pass by value the customer number or also known as ticket number
  		 * Return: long average wait time
         * Post Condition: average wait time is returned
         */
        void enterQueue(int customer);

        /*Removes a customer from the Queue
         * Pre-Condition: customer number must be of type integer
  		 * Arguments: None
  		 * Return: None
         * Post Condition: Customer is deleted from the Queue
         */
        int depart( );

        /* Checks if the queue is empty
         * Pre-Condition: Queue must be constructed properly or empty
         * Arguement: None
         * Return: integer of the customer that is being removed from the line
         * Post Condition: Returns true if the queue is empty. Returns false otherwise.
         */
        bool isEmpty( ) const;


        /* Processs whether the customer has entered the queue or is being helped
         * Pre-Condition: 1, 2 or 3 are the only valid inputs
         * Arguement: Pass by reference the class type DMVQueue to be modified
         * Return: None
         * Post Condition: Node is added or deleted; customer enters or leaves determined
         * based on if 1 or 2 is pressed, if 3 is pressed then exit the program
         */
        void processQueue(DMVQueue& aQueue);

    private:
        QueueNodePtr front;//Points to the head of a linked list.
                            //Items are removed at the head
        QueueNodePtr back;//Points to the node at the other end of the
                           //linked list. Items are added at this end.
        //incremented when a customer enters the line
        int customerNum;

        //incremented when 2 is pressed or is being helped
        int helpingCustomerNum;

        //vectors containing time entered and time of departure
        vector <long> timeIn;
        vector <long> timeOut;

        //stores the most up to date wait time
        long waitTime;

        //stores all the previous wait times
        vector <long> listWaitTimes;

        //calculated based on the 3 most recent wait times stored
        // stored in the list of wait times
        long averageWait;
    };

#endif
