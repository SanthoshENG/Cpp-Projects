#include <iostream>
#include <cstdlib>
#include <cstddef>
#include <ctime>
#include <vector>
#include "DMV.h"

using namespace std;


    DMVQueue::DMVQueue( ) : front(NULL), back(NULL)
    {
    	//initialized in the same line above
    }

    //not used in this application file
    DMVQueue::DMVQueue(const DMVQueue& aQueue)
    {
      if (aQueue.isEmpty())
      {
          front = back = NULL;

      }
      else
      {
          QueueNodePtr oldTemp = aQueue.front;
          QueueNodePtr newTemp;
          back = new DMVQueueNode;
          back->customer = oldTemp->customer;
          back->link = NULL;
          front = back;
          oldTemp = oldTemp->link;
          while(oldTemp != NULL)
          {
              newTemp = new DMVQueueNode;
              newTemp->customer = oldTemp->customer;
              newTemp-> link= NULL;
              back->link = newTemp;
              back = newTemp;
              oldTemp = oldTemp->link;

          }
      }

    }

    //deletes the queue
    DMVQueue::~DMVQueue( )
    {
        int next;
        while (! isEmpty())
        {
            next = depart();
        }
    }


    bool DMVQueue::isEmpty( ) const
    {

        return (back == NULL);

    }


    void DMVQueue::enterQueue(int item)
    {
        timeIn.push_back(timeQueue());
        if (isEmpty( ))
        {
            front = new DMVQueueNode;
            front->customer = item;
            front->link = NULL;
            back = front;
            cout <<"The line is empty"<<endl;
        }

        else
        {
            QueueNodePtr temp_ptr;
            temp_ptr = new DMVQueueNode;

			temp_ptr->customer = item;
            temp_ptr->link = NULL;
            back->link = temp_ptr;
            back = temp_ptr;
        }
    }


    int DMVQueue::depart( )
    {
        timeOut.push_back(timeQueue());
        if (isEmpty( ))
        {
            cout << "Error: Removing an item from an empty queue.\n";
            exit(1);
        }

        int result = front->customer;

        QueueNodePtr discard;
        discard = front;
        front = front->link;
        if (front == NULL)
            back = NULL;

        delete discard;

        return result;
    }

    void DMVQueue::processQueue(DMVQueue& aQueue)
    {

        int choice = 0;
        //list of incrementing variables
        int i = 0;
        int o = 0;
        int w = 0;
        customerNum = 0;
        helpingCustomerNum = 0;
        do
        {
            cout << "Enter '1' to simulate a customer's arrival, '2' to help the next customer, or '3' to quit" << endl;

            cin >> choice;

            if (choice == 1)
            {
                customerNum++;
                aQueue.enterQueue(customerNum);
                cout <<"Customer "<< customerNum << " entered the queue at time "<< timeIn.at(i) <<endl;
                i++;
            }
            else if (choice == 2)
            {
                helpingCustomerNum++;
                aQueue.depart();
                waitTime = calcWaitTime(timeIn, timeOut, o, w);
                listWaitTimes.push_back(waitTime);
                averageWait = calcAverageTime(listWaitTimes);
                if(helpingCustomerNum <= customerNum)
                {
                    cout<< "Customer "<< helpingCustomerNum << " is being helped at time "<< timeOut.at(o) << " Wait time = "<< waitTime << endl;
                    cout<< "The estimated wait time for customer " << helpingCustomerNum+1 << " is " << averageWait << " seconds"<< endl;
                    w++;
                    o++;
                }
                else
                {
                    cout<< "No more customers to help. Exiting Program" << endl;
                    exit(2);
                }
            }
            else if(choice == 3)
            {
                cout << "Exiting Program" << endl;
                exit(0);
            }
            else
            {
                cout << "Invalid input. Exiting program" << endl;
                exit (1);
            }
        }
        while(choice < 3);
    }
long DMVQueue:: timeQueue()
    {
        long seconds;
        seconds = static_cast<long>(time(NULL));
        return seconds;
    }
long DMVQueue:: calcWaitTime(vector <long> timeIn, vector <long> timeOut, int o, int w)
    {
        waitTime = timeOut.at(o)-timeIn.at(w);
        return waitTime;
    }
long DMVQueue:: calcAverageTime(vector <long> waitTimes)
    {

        long sum = 0;
        if(waitTimes.size()<= 3)
        {
            unsigned int i;
            for  (i = 0; i<waitTimes.size(); i++)
            {
                sum+=waitTimes.at(i);
            }
            long average = sum/i;
            return average;
        }
        else
        {
            long latest = waitTimes.at(waitTimes.size()-1);
            long secondlast = waitTimes.at(waitTimes.size()-2);
            long thirdlast = waitTimes.at(waitTimes.size()-3);

            long average1 = (latest + secondlast + thirdlast)/3;
            return average1;
        }
    }
