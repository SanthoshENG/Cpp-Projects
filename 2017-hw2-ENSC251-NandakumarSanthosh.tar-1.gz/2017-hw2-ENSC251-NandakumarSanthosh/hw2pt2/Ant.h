#ifndef ANT_H
#define ANT_H
#include "Organism.h"
#include <string>

using namespace std;

class Ant : public Organism
{

     public:

      /* Default Constructors
       * Pre-Conditions: object of type class Ant
       * Arguements: None
       * Return: None
       * Post-Conditions:Initializes the Ant
       */
      Ant();


      /* Constructor
       * Post Condition: to initialize the position of the
       * organism on the board
       * Arguements: int row and int column
       */
      Ant(int row, int column);

      /* moves the organism
       * pre condition: board is initialized
       * Arguments: 2D array of pointers
       * Post condition: Moves the organism
       */
      void move(Organism* grid[][MAXDIMS]);

      /* makes organism breed (multiplies)
       * pre condition: board is initialized
       * Arguments: 2D array of pointers
       * Post condition: Multiplies the organism
       */
      void breed(Organism* grid[][MAXDIMS]);

      /* checks if a move has been made in a time step
      * pre condition: board is initialized
      * Arguments: 2D array of pointers
      * Post condition: returns either true or false
      */
      string getSpecies();


     protected:

      //holds the species ant
      string species;

};

#endif

