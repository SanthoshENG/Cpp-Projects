#include "Organism.h"
#include "Ant.h"
#include "Doodlebug.h"
#include <iostream>
#include <string>
#include <ctime>

#include <cstdlib>
#include <vector>
#include <algorithm>

using namespace std;




/***************************************************************
* Function: fillWithNull
* Description: Fills 20x20 grid with null pointers
* ************************************************************/
void buildEmpty(Organism* grid[][MAXDIMS]);

/***************************************************************
* Function: initializeGrid
* Description: Initializes 20x20 grid with 100 Ants and 5 Doodlebugs
* ************************************************************/
void buildGrid(Organism* grid[][MAXDIMS]);

/***************************************************************
* Function: printGrid
* Description: Prints values of 20x20 grid
* ************************************************************/
void printSimulation(Organism* grid[][MAXDIMS]);

/***************************************************************
* Function: advanceTime
* Description: Goes through 20x20 grid. Each non NULL pointer is placed in
*              a vector randomVec. randomVec is shuffled into random order
*              and then iterated through. All Organisms move (if
*              appropriate), then all Organisms breed (if appropriate),
*              then all Doodlebugs starve(if appropriate). Any Organisms
*              that have died are then deleted.
* ************************************************************/
//void simulate(Organism* grid[][MAXDIMS]);


int main()
{

     char toContinue;
     Organism* world[MAXDIMS][MAXDIMS];   //Create 20x20 grid of Organism pointers

     srand(time(NULL));       //Seed random number generator
     buildGrid(world); //Fill grid with Organisms and NULL pointers

     do{

      printSimulation(world);
    //  simulate(world);

      cout << "Press 1 to continue simulation. Enter any other key to end.";
      cin >> toContinue;

     }while(toContinue == '1');

     return 0;

}

void buildEmpty(Organism* grid[][MAXDIMS])
{

     for(int i = 0; i < MAXDIMS; i++)
     {
      for(int j = 0; j < MAXDIMS; j++)
      {
           grid[i][j] = NULL;
      }
     }
}

void buildGrid(Organism* grid[][MAXDIMS])
{

     buildEmpty(grid);

     // Fill grid with 100 Ants
     for(int i = 0; i < MAXDIMS; i++)
     {
      for(int j = 0; j < MAXDIMS; j++)
      {

        if(i % 2 == 0)
        {   // Fill in rows with even index
         if((j + 1) % 4 == 0)
         {

        	 grid[i][j] = new Ant(i, j);

          }
        }
      else
      {       // Fill in rows with odd index
          if((j + 2) % 4 == 0)
          {
               grid[i][j] = new Ant(i, j);

          }
       }
      }
     }

     // Fill grid with 5 Doodlebugs
     int bugs = 0;
     while (bugs < 5)
     {
    	 int x = rand()%20;
    	 int y = rand()%20;

    	 if (grid[x][y] == 0)
    	 {
    		 grid[x][y] = new Doodlebug(x,y);
    		 bugs++;
    	 }


     }

}

void printSimulation(Organism* grid[][MAXDIMS])
{

     for(int i = 0; i < MAXDIMS; i++)
     {

      for(int j = 0; j < MAXDIMS; j++)
      {

           if(grid[i][j] == NULL)
           {
        	   cout << ".";
           }
           else if((*grid[i][j]).getSpecies() == "Ant"){
        	   cout << "A";
           }
           else if((*grid[i][j]).getSpecies() == "Doodlebug")
           {
        	   cout << "D";
           }
      }

   cout << endl;

     }
}

