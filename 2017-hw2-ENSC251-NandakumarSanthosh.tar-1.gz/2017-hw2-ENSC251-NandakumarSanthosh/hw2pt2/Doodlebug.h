#ifndef DOODLEBUG_H
#define DOODLEBUG_H

#include "Organism.h"
#include <string>

using std::string;

class Doodlebug : public Organism
{

     public:

      // Constructors
	  // initializes default values for Doodlebug
	Doodlebug();

    /* Constructor
     * Post Condition: to initialize the position of the
     * Doodlebug on the board
     * Arguements: int row and int column
     */
	Doodlebug(int row, int column);

    /* moves the doodlebug
     * pre condition: board is initialized
     * Arguments: 2D array of pointers
     * Post condition: Moves the doodlebug
     */
      void move(Organism* grid[][MAXDIMS]);


      /* makes organism breed (multiplies)
       * pre condition: board is initialized
       * Arguments: 2D array of pointers
       * Post condition: Multiplies the organism
       */
      void breed(Organism* grid[][MAXDIMS]);

   /* starve function
       * pre condition: board is initialized
       * Arguments: 2D array of pointers
       * Post condition: if the doodlebug has starved
       * 3 straight times  the organism starves the
       * organism dies, setDeath is called
       */
      void starve(Organism* grid[][MAXDIMS]);

      /* checks if a move has been made in a time step
      * pre condition: board is initialized
      * Arguments: 2D array of pointers
      * Post condition: returns either true or false
      */

      string getSpecies();

     protected:

      string species;
      // stores number of  timesteps Doodlebug has not eaten
      int stepsNotEaten;

};

#endif


