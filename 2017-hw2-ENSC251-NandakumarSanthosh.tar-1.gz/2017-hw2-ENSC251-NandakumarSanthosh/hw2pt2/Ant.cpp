#include "Ant.h"
#include <ctime>
#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

Ant::Ant() : Organism()
{

     species = "Ant";

}

Ant::Ant(int row, int column) : Organism(row,column)
{

     species = "Ant";

}

void Ant::move(Organism* grid[][MAXDIMS])
{



}

void Ant::breed(Organism* grid[][MAXDIMS])
{



}

string Ant::getSpecies()
{

     return species;

}
