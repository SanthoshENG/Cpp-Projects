
#include "Doodlebug.h"
#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

Doodlebug::Doodlebug() : Organism()
{

     species = "Doodlebug";
     stepsNotEaten = 0;

}

Doodlebug::Doodlebug(int row, int column) : Organism(row,column)
{

     species = "Doodlebug";
     stepsNotEaten = 0;

}

void Doodlebug::move(Organism* grid[][20])
{



}

void Doodlebug::breed(Organism* grid[][MAXDIMS])
{



}

void Doodlebug::starve(Organism* grid[][20])
{

     if(stepsNotEaten == 3)
     {

      died = true;
      grid[rows][columns] = NULL;

     }
}

string Doodlebug::getSpecies()
{

     return species;

}
