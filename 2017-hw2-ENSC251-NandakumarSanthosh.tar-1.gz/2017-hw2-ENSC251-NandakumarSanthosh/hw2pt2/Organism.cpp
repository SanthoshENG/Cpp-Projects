
#include "Organism.h"
#include <iostream>
#include <cstring>
using namespace std;



Organism::Organism()
{

     nobreeding = 0;
     moved = false;
     died = false;
     rows = -1;
     columns = -1;
}

Organism::Organism(int row, int column)
{

     nobreeding = 0;
     moved = false;
     died = false;
     rows = row;
     columns = column;
}

void Organism::move(Organism* grid[][MAXDIMS])
{

     // defined in derived class

}

void Organism::breed(Organism* grid[][MAXDIMS])
{

    // defined in derived class


}

void Organism::starve(Organism* grid[][MAXDIMS])
{

    // defined in derived class


}

string Organism::getSpecies()
{

    // defined in derived class


}

bool Organism::hasMoved() const
{

     return moved;

}

void Organism::setMoved(bool doneMoving)
{

     moved = doneMoving;

}

bool Organism::checkDeath() const
{

     return died;

}

void Organism::setDeath(bool death)
{

     died = death;

}
