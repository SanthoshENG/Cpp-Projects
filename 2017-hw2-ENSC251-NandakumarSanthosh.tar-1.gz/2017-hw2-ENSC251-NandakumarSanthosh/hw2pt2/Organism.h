
#ifndef ORGANISM_H
#define ORGANISM_H
#include <iostream>
#include <string>
using namespace std;
const int MAXDIMS = 20;

//parent class or base class to doodlebug and ant
class Organism
{

     public:

      // Default constructor
	  //Initializes a organism
      Organism();

      /* Constructor
       * Post Condition: to initialize the position of the
       * organism on the board
       * Arguements: int row and int column
       */
      Organism(int row, int column);


      /* moves the organism
       * pre condition: board is initialized
       * Arguments: 2D array of pointers
       * Post condition: Moves the organism
       */
      virtual void move(Organism* grid[][MAXDIMS]);

      /* makes organism breed (multiplies)
       * pre condition: board is initialized
       * Arguments: 2D array of pointers
       * Post condition: Multiplies the organism
       */
      virtual void breed(Organism* grid[][MAXDIMS]);


      /* Virtual starve function
       * pre condition: board is initialized
       * Arguments: 2D array of pointers
       * Post condition: if the organism has starved
       * 3 straight times  the organism starves the
       * organism dies, setDeath is called
       */
      virtual void starve(Organism* grid[][MAXDIMS]);

      /* Virtual accessor function which retrieves species
       * pre condition: species exists as a string
       * Arguments: None
       * Post condition: returns species as a string
       */
      virtual string getSpecies();


       /* checks if a move has been made in a time step
       * pre condition: board is initialized
       * Arguments: 2D array of pointers
       * Post condition: returns either true or false
       */
      bool hasMoved() const;

      /* Sets organism as moved
       * pre condition: board is initialized
       * Arguments: boolean value of either true or false
       * Post condition: sets the
       */
      void setMoved(bool doneMoving);

      /* checks if organism is dead
       * pre condition: board is initialized
       * Arguments: None
       * Post condition: returns true or false
       */
      bool checkDeath() const;

      /* sets the organism to dead
       * pre condition: board is initialized
       * Arguments: None
       * Post condition: returns true or false
       */
      void setDeath(bool death);

     protected:
      //# timesteps without breeding
      int nobreeding;
      // stores if Organism has moved within a timestep
      bool moved;
      // stores if Organism has died or not
      bool died;
      //horizontal position in grid
      int rows;
      // vertical position in grid
      int columns;
};

#endif
