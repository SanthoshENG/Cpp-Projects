// I declare that this assignment is my own work and that I have correctly acknowledged the
// work of others. I acknowledged that I have read and followed the Academic Honesty and
// Integrity related policies as outlined in the syllabus.
//
// Tal Kazakov (DATE) Sept 28, 2017
//
// 301319792
//
// Santhosh Nandakumar (DATE) Sept 28, 2017
//
// 301300261
//
// Group #49

#include <iostream>
#include <cstdlib>
#include <string>
#include <sstream>
#include <string.h>
#include <fstream>
#include <iomanip>



using namespace std;

//Global Constants used throughout the program

const string DIGIT_0 = "11000";
const string DIGIT_1 = "00011";
const string DIGIT_2 = "00101";
const string DIGIT_3 = "00110";
const string DIGIT_4 = "01001";
const string DIGIT_5 = "01010";
const string DIGIT_6 = "01100";
const string DIGIT_7 = "10001";
const string DIGIT_8 = "10010";
const string DIGIT_9 = "10100";
const int LENGTH_BAR_CODE = 27;
const int LENGTH_ZIP_CODE = 5;


//This class stores the Bar Code and Zip Code system used by the US postal service
//The class decodes the Bar Code and Zip Code and is able to convert back and forth 
//between the two types of information based on the information the user inputs
//Program also checks for errors in user inputs


class POSTNET
{
    public:     

//Default Constructor

    POSTNET();  
    //Intializes Bar Code and Zip Code values to zero prior to user input
    
//Overload Constructor
    POSTNET(int input1);
    //Stores an integer value for Zip Code based on user input
    
    POSTNET(string Istring);
    //Stores the Bar Code as a string based on user input

//Member Functions
    
    void CheckInput(string input, POSTNET Zip1);
    //Takes in the string inputed by the user and the object that is of type POSTNET
    //Reads input and chooses correct pathway to output either Zip Code or Bar Code

private:
    void ExtractBarCode (string& BarCode);
    //Uses the Bar Code string inputed by the user
    //Checks if first value and last value of Bar Code are ones otherwise returns an error
    //If input is proper the function removes the first and last values of the Bar Code which are useless
    
    void ProcessBar(string BarCode);
    //Uses extracted Bar Code string to convert the Bar Code into a Zip Code
    //If any errors in user input returns an error message
    
    void ProcessZip(string ZipCode);
    //Uses Zip Code and converts it to a Bar Code
    //Checks for any errors in user input of Zip Code and returns an error if any are found

    int ZipCodeVar;
    //Stores an integer value of the Zip Code
    
    string BarCode;
    //Stores the Bar Code as a string

};

int main()
{
    
string input;
POSTNET Zip1;
cout << "Enter Zip Code or Bar Code"<< endl;
cin >> input;

Zip1.CheckInput(input, Zip1);


return 0;

}
//----------------------------CONSTRUCTOR DEFINITIONS--------------------------------------------------------------------------------------
POSTNET::POSTNET()  //Default Constructor
{
   ZipCodeVar = 0;
    BarCode ="0";
}


POSTNET::POSTNET(string Istring) //Overload Constructor storing user inputed Bar Code as string
{
    BarCode = Istring;
}

POSTNET::POSTNET(int input) //Overload Constructor storing user inputed Zip Code as an integer
{
    ZipCodeVar = input;
}

void POSTNET::CheckInput(string input, POSTNET Zip1)//Checks for valid input and calls required member function
{
    int size = 0;
    int Zip = 0;
    
    size = input.size();
    if( size == LENGTH_BAR_CODE )
{
    cout << "You entered a Bar Code" << endl;
    Zip1 = POSTNET(input);
    Zip1.ExtractBarCode(input);
    Zip1.ProcessBar(input);
}
else if ( size == LENGTH_ZIP_CODE )
{
    cout << "You entered a Zip Code" << endl;
    string stringToInteger(input);
	stringstream str(stringToInteger);
	
	str >> Zip;
    Zip1 = POSTNET(Zip);
    
    Zip1.ProcessZip(input);
    
}

else
{
    cout << "Invalid Input"<< endl;
    exit;
}
    
}

void POSTNET::ExtractBarCode(string& BarCode)//Removes the leading and ending ones which are common to all Bar Codes
{
   
    string ExBarCode1 = "0";
    string ExBarCode2 = "0";
    
    if ( BarCode[0] != '1' || BarCode[26] != '1')
    {
        cout << "Invalid Input, Not a Bar Code!" << endl;
        exit(3);
    }
    

    
        ExBarCode1 = BarCode.erase(0,1);
        ExBarCode2 = ExBarCode1.erase(25,26);
        BarCode = ExBarCode2;
    
}

void POSTNET::ProcessBar(string BarCode) //Converts the user entered Bar Code to Zip Code given no errors in entry
{
    string BarPiece1 = "00000";
    string BarPiece2 = "00000";
    string BarPiece3 = "00000";
    string BarPiece4 = "00000";
    string BarPiece5 = "00000";
    int ZipDig1 = 0;
    int ZipDig2 = 0;
    int ZipDig3 = 0;
    int ZipDig4 = 0;
    int ZipDig5 = 0;
    int TotalZip = 0;
   
    BarPiece1[0]=BarCode[0];
    BarPiece1[1]=BarCode[1];
    BarPiece1[2]=BarCode[2];
    BarPiece1[3]=BarCode[3];
    BarPiece1[4]=BarCode[4];
    
    
    BarPiece2[0]=BarCode[5];
    BarPiece2[1]=BarCode[6];
    BarPiece2[2]=BarCode[7];
    BarPiece2[3]=BarCode[8];
    BarPiece2[4]=BarCode[9];
    
    BarPiece3[0]=BarCode[10];
    BarPiece3[1]=BarCode[11];
    BarPiece3[2]=BarCode[12];
    BarPiece3[3]=BarCode[13];
    BarPiece3[4]=BarCode[14];
    
    BarPiece4[0]=BarCode[15];
    BarPiece4[1]=BarCode[16];
    BarPiece4[2]=BarCode[17];
    BarPiece4[3]=BarCode[18];
    BarPiece4[4]=BarCode[19];
    
    BarPiece5[0]=BarCode[20];
    BarPiece5[1]=BarCode[21];
    BarPiece5[2]=BarCode[22];
    BarPiece5[3]=BarCode[23];
    BarPiece5[4]=BarCode[24];
   
    if (BarPiece1 == DIGIT_0)
    {
        ZipDig1 = 0;
    }
    else if (BarPiece1 == DIGIT_1)
    {
        ZipDig1 = 10000;
    }
    else if (BarPiece1 == DIGIT_2)
    {
        ZipDig1 = 20000;
    }
    else if (BarPiece1 == DIGIT_3)
    {
        ZipDig1 = 30000;
    }
    else if (BarPiece1 == DIGIT_4)
    {
        ZipDig1 = 40000;
    }
    else if (BarPiece1 == DIGIT_5)
    {
        ZipDig1 = 50000;
    }
    else if (BarPiece1 == DIGIT_6)
    {
        ZipDig1 = 60000;
    }
    else if (BarPiece1 == DIGIT_7)
    {
        ZipDig1 = 70000;
    }
    else if (BarPiece1 == DIGIT_8)
    {
        ZipDig1 = 80000;
    }
    else if (BarPiece1 == DIGIT_9)
    {
        ZipDig1 = 90000;
    }
    else 
    {
        cout << "Invalid BarCode" << endl;
        exit(1);
    }
    
    
    if (BarPiece2 == DIGIT_0)
    {
        ZipDig2 = 0;
    }
    else if (BarPiece2 == DIGIT_1)
    {
        ZipDig2 = 1000;
    }
    else if (BarPiece2 == DIGIT_2)
    {
        ZipDig2 = 2000;
    }
    else if (BarPiece2 == DIGIT_3)
    {
        ZipDig2 = 3000;
    }
    else if (BarPiece2 == DIGIT_4)
    {
        ZipDig2 = 4000;
    }
    else if (BarPiece2 == DIGIT_5)
    {
        ZipDig2 = 5000;
    }
    else if (BarPiece2 == DIGIT_6)
    {
        ZipDig2 = 6000;
    }
    else if (BarPiece2 == DIGIT_7)
    {
        ZipDig2 = 7000;
    }
    else if (BarPiece2 == DIGIT_8)
    {
        ZipDig2 = 8000;
    }
    else if (BarPiece2 == DIGIT_9)
    {
        ZipDig2 = 9000;
    }
    else 
    {
        cout << "Invalid BarCode" << endl;
        exit(1);
    }
    
    
    if (BarPiece3 == DIGIT_0)
    {
        ZipDig3 = 0;
    }
    else if (BarPiece3 == DIGIT_1)
    {
        ZipDig3 = 100;
    }
    else if (BarPiece3 == DIGIT_2)
    {
        ZipDig3 = 200;
    }
    else if (BarPiece3 == DIGIT_3)
    {
        ZipDig3 = 300;
    }
    else if (BarPiece3 == DIGIT_4)
    {
        ZipDig3 = 400;
    }
    else if (BarPiece3 == DIGIT_5)
    {
        ZipDig3 = 500;
    }
    else if (BarPiece3 == DIGIT_6)
    {
        ZipDig3 = 600;
    }
    else if (BarPiece3 == DIGIT_7)
    {
        ZipDig3 = 700;
    }
    else if (BarPiece3 == DIGIT_8)
    {
        ZipDig3 = 800;
    }
    else if (BarPiece3 == DIGIT_9)
    {
        ZipDig3 = 900;
    }
    else 
    {
        cout << "Invalid BarCode" << endl;
        exit(1);
    }


    if (BarPiece4 == DIGIT_0)
    {
        ZipDig4 = 0;
    }
    else if (BarPiece4 == DIGIT_1)
    {
        ZipDig4 = 10;
    }
    else if (BarPiece4 == DIGIT_2)
    {
        ZipDig4 = 20;
    }
    else if (BarPiece4 == DIGIT_3)
    {
        ZipDig4 = 30;
    }
    else if (BarPiece4 == DIGIT_4)
    {
        ZipDig4 = 40;
    }
    else if (BarPiece4 == DIGIT_5)
    {
        ZipDig4 = 50;
    }
    else if (BarPiece4 == DIGIT_6)
    {
        ZipDig4 = 60;
    }
    else if (BarPiece4 == DIGIT_7)
    {
        ZipDig4 = 70;
    }
    else if (BarPiece4 == DIGIT_8)
    {
        ZipDig4 = 80;
    }
    else if (BarPiece4 == DIGIT_9)
    {
        ZipDig4 = 90;
    }
    else 
    {
        cout << "Invalid BarCode" << endl;
        exit(1);
    }
    
    if (BarPiece5 == DIGIT_0)
    {
        ZipDig5 = 0;
    }
    else if (BarPiece5 == DIGIT_1)
    {
        ZipDig5 = 1;
    }
    else if (BarPiece5 == DIGIT_2)
    {
        ZipDig5 = 2;
    }
    else if (BarPiece5 == DIGIT_3)
    {
        ZipDig5 = 3;
    }
    else if (BarPiece5 == DIGIT_4)
    {
        ZipDig5 = 4;
    }
    else if (BarPiece5 == DIGIT_5)
    {
        ZipDig5 = 5;
    }
    else if (BarPiece5 == DIGIT_6)
    {
        ZipDig5 = 6;
    }
    else if (BarPiece5 == DIGIT_7)
    {
        ZipDig5 = 7;
    }
    else if (BarPiece5 == DIGIT_8)
    {
        ZipDig5 = 8;
    }
    else if (BarPiece5 == DIGIT_9)
    {
        ZipDig5 = 9;
    }
    else 
    {
        cout << "Invalid BarCode" << endl;
        exit(1);
    }   
    
    TotalZip = ZipDig1 + ZipDig2 + ZipDig3 + ZipDig4 + ZipDig5;
    
    cout << "The corresponding Zip Code is:"<< endl;
    
    if (ZipDig1 == 0&& ZipDig2 == 0 && ZipDig3 == 0 && ZipDig4 == 0 && ZipDig5 == 0)
    {
        cout<<"0000";
    }
    else if (ZipDig1 == 0&& ZipDig2 == 0 && ZipDig3 == 0 && ZipDig4 == 0)
    {
        cout << "0000";
    }
     else if (ZipDig1 == 0&& ZipDig2 == 0 && ZipDig3 == 0 )
    {
        cout << "000";
    }
     else if (ZipDig1 == 0&& ZipDig2 == 0)
    {
        cout << "00";
    }
    else if (ZipDig1 == 0)
    {
        cout << "0";
    }
    

    
   
    cout << TotalZip << endl;
    ZipCodeVar = TotalZip;
    
        
}
void POSTNET::ProcessZip(string ZipCode) //Converts user inputed Zip Code to a Bar Code given no errors in input
{
   
   string BarPiece1 = "00000";
   string BarPiece2 = "00000";
   string BarPiece3 = "00000";
   string BarPiece4 = "00000";
   string BarPiece5 = "00000";
   string FinalBar = "0000000000000000000000000";
   
    if (ZipCode[0] == '0')
    {
       BarPiece1 = DIGIT_0;
    }
    else if (ZipCode[0] == '1')
    {
        BarPiece1 = DIGIT_1;
    }
    else if (ZipCode[0] == '2')
    {
        BarPiece1 = DIGIT_2;
    }
    else if (ZipCode[0] == '3')
    {
        BarPiece1 = DIGIT_3;
    }
    else if (ZipCode[0] == '4')
    {
        BarPiece1 = DIGIT_4;
    }
    else if (ZipCode[0] == '5')
    {
        BarPiece1 = DIGIT_5;
    }
    else if (ZipCode[0] == '6')
    {
        BarPiece1 = DIGIT_6;
    }
    else if (ZipCode[0] == '7')
    {
        BarPiece1 = DIGIT_7;
    }
    else if (ZipCode[0] == '8')
    {
        BarPiece1 = DIGIT_8;
    }
    else if (ZipCode[0] == '9')
    {
        BarPiece1 = DIGIT_9;
    }
    else 
    {
        cout << "Invalid Zip Code has been entered";
        exit(2);
    }
    
    
    if (ZipCode[1] == '0')
    {
       BarPiece2 = DIGIT_0;
    }
    else if (ZipCode[1] == '1')
    {
        BarPiece2 = DIGIT_1;
    }
    else if (ZipCode[1] == '2')
    {
        BarPiece2 = DIGIT_2;
    }
    else if (ZipCode[1] == '3')
    {
        BarPiece2 = DIGIT_3;
    }
    else if (ZipCode[1] == '4')
    {
        BarPiece2 = DIGIT_4;
    }
    else if (ZipCode[1] == '5')
    {
        BarPiece2 = DIGIT_5;
    }
    else if (ZipCode[1] == '6')
    {
        BarPiece2 = DIGIT_6;
    }
    else if (ZipCode[1] == '7')
    {
        BarPiece2 = DIGIT_7;
    }
    else if (ZipCode[1] == '8')
    {
        BarPiece2 = DIGIT_8;
    }
    else if (ZipCode[1] == '9')
    {
        BarPiece2 = DIGIT_9;
    }
    else 
    {
        cout << "Invalid Zip Code has been entered";
        exit(2);
    }
    
    
    if (ZipCode[2] == '0')
    {
       BarPiece3 = DIGIT_0;
    }
    else if (ZipCode[2] == '1')
    {
        BarPiece3 = DIGIT_1;
    }
    else if (ZipCode[2] == '2')
    {
        BarPiece3 = DIGIT_2;
    }
    else if (ZipCode[2] == '3')
    {
        BarPiece3 = DIGIT_3;
    }
    else if (ZipCode[2] == '4')
    {
        BarPiece3 = DIGIT_4;
    }
    else if (ZipCode[2] == '5')
    {
        BarPiece3 = DIGIT_5;
    }
    else if (ZipCode[2] == '6')
    {
        BarPiece3 = DIGIT_6;
    }
    else if (ZipCode[2] == '7')
    {
        BarPiece3 = DIGIT_7;
    }
    else if (ZipCode[2] == '8')
    {
        BarPiece3 = DIGIT_8;
    }
    else if (ZipCode[2] == '9')
    {
        BarPiece3 = DIGIT_9;
    }
    else 
    {
        cout << "Invalid Zip Code has been entered";
        exit(2);
    }
    
    
    if (ZipCode[3] == '0')
    {
       BarPiece4 = DIGIT_0;
    }
    else if (ZipCode[3] == '1')
    {
        BarPiece4 = DIGIT_1;
    }
    else if (ZipCode[3] == '2')
    {
        BarPiece4 = DIGIT_2;
    }
    else if (ZipCode[3] == '3')
    {
        BarPiece4 = DIGIT_3;
    }
    else if (ZipCode[3] == '4')
    {
        BarPiece4 = DIGIT_4;
    }
    else if (ZipCode[3] == '5')
    {
        BarPiece4 = DIGIT_5;
    }
    else if (ZipCode[3] == '6')
    {
        BarPiece4 = DIGIT_6;
    }
    else if (ZipCode[3] == '7')
    {
        BarPiece4 = DIGIT_7;
    }
    else if (ZipCode[3] == '8')
    {
        BarPiece4 = DIGIT_8;
    }
    else if (ZipCode[3] == '9')
    {
        BarPiece4 = DIGIT_9;
    }
    else 
    {
        cout << "Invalid Zip Code has been entered";
        exit(2);
    }
    
    
    if (ZipCode[4] == '0')
    {
       BarPiece5 = DIGIT_0;
    }
    else if (ZipCode[4] == '1')
    {
        BarPiece5 = DIGIT_1;
    }
    else if (ZipCode[4] == '2')
    {
        BarPiece5 = DIGIT_2;
    }
    else if (ZipCode[4] == '3')
    {
        BarPiece5 = DIGIT_3;
    }
    else if (ZipCode[4] == '4')
    {
        BarPiece5 = DIGIT_4;
    }
    else if (ZipCode[4] == '5')
    {
        BarPiece5 = DIGIT_5;
    }
    else if (ZipCode[4] == '6')
    {
        BarPiece5 = DIGIT_6;
    }
    else if (ZipCode[4] == '7')
    {
        BarPiece5 = DIGIT_7;
    }
    else if (ZipCode[4] == '8')
    {
        BarPiece5 = DIGIT_8;
    }
    else if (ZipCode[4] == '9')
    {
        BarPiece5 = DIGIT_9;
    }
    else 
    {
        cout << "Invalid Zip Code has been entered";
        exit(2);
    }
    
    FinalBar = BarPiece1 + BarPiece2 + BarPiece3 + BarPiece4 + BarPiece5;
    
    FinalBar = "1" + FinalBar + "1";
    
    cout << "The corresponding Bar Code is:"<< endl;
    cout << FinalBar;
    
    BarCode = FinalBar;
    
}

//End Of code----------------------------------------------------------