// I declare that this assignment is my own work and that I have correctly acknowledged the
// work of others. I acknowledged that I have read and followed the Academic Honesty and
// Integrity related policies as outlined in the syllabus.
//
//
//WHEN I DOWNLOADED THIS CODE FROM C9.IO INTO LINUIX IT WAS GIVNIG ME SOME ERRORS WHERE AS IN c9 IT 
//IT WAS WORKING PERFECTLY FINE. IF IT IT POSSIBLE FOR YOU TO TEST THIS PART OF THE CODE ELSEWHERE 
//WE WOULD GREATLY APPRECIATE, IF YOU NEED TO CONTACT US YOU CAN REACH US AT snandaku@sfu.ca
//THANK YOU FOR YOUR TIME
//
//Tal Kazakov (DATE) Sept 28, 2017
//
// 301319792
//
// Santhosh Nandakumar (DATE) Sept 28, 2017
//
// 301300261
//
// Group #49

#include <iostream>
#include <cstdlib>
#include <string>
#include <sstream>
#include <string.h>
#include <fstream>
#include <iomanip>



using namespace std;

//Global Constants used throughout the program

const int MAX_SIZE = 50;

class VECTORDOUBLE
{
    public:     

string publicChecker;

//Constructors
VECTORDOUBLE(); // Default Constructor 
   
VECTORDOUBLE(const VECTORDOUBLE &v);  //Copy Constructor
    
VECTORDOUBLE(int input1); //Overloaded Constructor

//Destructor
~VECTORDOUBLE();

//Other Members
void Push_Back(); 
//allows user to push double values into the vector


double value_at(int Index); 
// user enters the index of desired value in the arguement
// function returns the double value stored at that index

void change_value_at(double ChangedValue, int Index); 
//user enters the value that needs to replace orginal value and the index of that value
//function replaces original value with desired valiue

//void resize(int input1);


int Capacity();
//returns the capacity of the vector as an integer


int SizeOfVector();
//returns the number of used elements in the array as an integer


//Operators
//friend void VECTORDOUBLE operator =(const VECTORDOUBLE& Vector1);
//Equates one vector to another

//friend bool VECTORDOUBLE operator ==(const VECTORDOUBLE& Vector1, const VECTORDOUBLE& Vector2);
//Checks if two vectors are equal

private:
    
    int max_count;  // Will be the size of the dynamic array of DOUBLES
    int count; // The number of ARRAY SLOTS that actually hold a value in the current program.
    double *vectorArray = NULL; //Dynamic Array

};

int main ()
{
   
   
   VECTORDOUBLE Vector;
   
   Vector.Push_Back();
   
   cout << "The value at index 2 is " << Vector.value_at(2) << endl;
   
   Vector.change_value_at(23.5678, 3);
   
   cout << endl << "The capacity of the vector is "<< Vector.Capacity() << endl;
  
   cout << "The size of this vector is " << Vector.SizeOfVector() << endl;
   
   VECTORDOUBLE Vector1(4);
   

   
   
    return 0;
}

VECTORDOUBLE::VECTORDOUBLE() //Creates Dynamic array and intializes to length 50
{
    
    vectorArray = new double [MAX_SIZE];
    max_count = 0;
}

VECTORDOUBLE::VECTORDOUBLE(int input1)
{
    
    vectorArray = new double [input1];
    max_count = input1;
}
VECTORDOUBLE::~VECTORDOUBLE() //dealocates memory
{
    delete [] vectorArray;
    vectorArray = NULL;
}

void VECTORDOUBLE::Push_Back()
{
    
    string checker ="0";
    double Number = 0;
    int size = 0;
    int i = 0;
    
    if (max_count == 0)
    {
        max_count = MAX_SIZE;
    }

    cout << "Enter the numbers corresponding to the Vector, 1 component at a time  and then pressing ENTER" << endl;
    cout << "When you are done entering data, ENTER 'DONE' or 'done'"<<endl;


    for (size=0; size < max_count; size++)
    {
    
        cin>>checker;
   
       
            if (checker=="DONE"|| checker == "done" || checker == "Done")
            {
                cout << "You have chosen there to be " << size << " Components in your Vector"<<endl;
                publicChecker = checker;
                break;
            }
             if ( ! (istringstream(checker) >> Number) ) 
            {
                cout << "Number was not entered! Ignoring input!" << endl;
                size--;
            }
            else 
            {
                vectorArray[size] = Number;
                
            }

    }
    
    count = size;


}

double VECTORDOUBLE::value_at(int Index)
{
    double value;
    value = 0;
    value = vectorArray[Index];
    return value;
}

void VECTORDOUBLE::change_value_at(double ChangedValue, int Index)
{
    vectorArray[Index] = ChangedValue;
    cout << "The value has been changed at index " << Index << " to " << vectorArray[Index];
}

int VECTORDOUBLE::Capacity()
{

    return max_count;
    
}

int VECTORDOUBLE::SizeOfVector()
{
    
    return count;
}

/*void VECTORDOUBLE::resize(int input1)
{
    string checker = "0";
    double Number = 0;
    CopyDynamicVectorArray = new double[input1];

    if (input1 > max_count )
    {

        cout << "ok your at 50 , keep going"<<endl;
        for (int i = 0; i < input1; i++)
        {
     
      
            if (i <max_count)
             {
                cout << vectorArray[i];
                CopyDynamicVectorArray[i]=vectorArray[i];
             
             
                    cin >> checker;
           
                    if (checker =="DONE"|| checker == "done" || checker == "Done")
                    {
                        cout << "You have chosen there to be " << i << " Components in your Vector"<<endl;
                        break;
                    }
                     
                    if ( ! (istringstream(checker) >> Number) ) 
                    {
                        cout << "Number was not entered! Ignoring input!" << endl;
                        i--;
                    }
                    else 
                    {
                        CopyDynamicVectorArray[i] = Number;
                
                    }
                
                
            
            }
       }
       
       delete[] vectorArray;
       vectorArray = NULL;
       
     
    }
    else
    {
        //vectorArray[]
    }
  
  
    
}
void VECTORDOUBLE::operator =(const VECTORDOUBLE& Vector1)
{
    int Size;
    int i;
    Size = Vector1.size();
    delete [] vectorArray;
    max_count = Size;
    count = Size;
    for (i=0; i<max_count; i++)
    {
        vectorArray[i]=Vector1.vectorArray[i];
    
    }
    
    
}
bool operator ==(const VECTORDOUBLE& Vector1, const VECTORDOUBLE& Vector2)
{
    int Size1;
    Size1 = Vector1.size();
    int Size2;
    Size2 = Vector2.size();
    if (Size1 == Size2)
    {
        for (int i = 0 ; i<Size1; i++)
        {
            if (Vector1[i] != Vector2[i])
            {
                return false;
            }
            else
            {
                continue;
            }
        }
        return true;
    }
}*/





