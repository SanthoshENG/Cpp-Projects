// I declare that this assignment is my own work and that I have correctly acknowledged the
// work of others. I acknowledged that I have read and followed the Academic Honesty and
// Integrity related policies as outlined in the syllabus.
//
// Santhosh Nandakumar  September 29, 2017
//
// 301300261


/*quick sort algorithm */

//Read Quick Sort Algorithm from wikipedia
/*
The code is close but it has some errors so it is not doing
what it is supposed to do. Read the Quick Sort Algorithm
and debug the code to print the correct output.

Also write the code for reading the numbers from the file "input.txt"
provided in the folder "prob2"
NOTE:- DO NOT hardcode the size of the file . Create a constant variable
max_length = 200, which will be the maximum size of the file.
//---------------------------------------------------------------
NOTE: DO NOT ADD ANY COUT STATEMENTS IN THE FINAL SUBMISSION
OF THE CODE. ALSO, DO NOT MODIFY THE SEQUENCE OF THE INPUT, OR
CHANGE THE INPUT
//---------------------------------------------------------------
*/

#include <cstdlib>
#include <iostream>
#include <fstream>
using namespace std;

//Prints the inputed integers from the input file
//Called throughout the program after every iteration of the Quick sort
void print_array(int array[], int low, int hi)
{
        cout<< "quick sort partition steps: ";
        for (int j=low; j<=hi;j++)
        {
                cout <<" "<< array[j];
        }
        cout << endl;
}//end of print_array

//Switches the value of two elements in the input array to be sorted
//Takes in the array
void swap (int arr[], int i, int j)
{
        int tempVariable; //no temporary variable was declared

        tempVariable = arr[i];
        arr[i] = arr[j];
        arr[j] = tempVariable;

        return;
}

//partitions of the array to be sorted in parts
//Takes in the input array and the max anf min indices
//Returns the pivot named i
int partition (int arr[], int low, int hi)
{
        int pivot = arr[hi];
        int i = low;

        for (int j = low; j<hi; j++)
        {
                if (arr[j] <= pivot)
                {
                        swap(arr, i, j);
                        i++;
                }
        }
        print_array(arr, low, hi);
        swap(arr, i, hi);
        return i;
}


//Main sorting functions that performs the algorithm of the quicksort
//Takes in the array from input file and the max and min indices
//Sorts the array
//Function is recursive
void quick_sort(int arr[], int low, int high)
{
        int pivot; //missing semicolon after pivot

        if (low < high) //previously named hi which is incorrect
        {
                pivot = partition(arr, low, high);
                quick_sort(arr, low, pivot-1);
                quick_sort(arr, pivot+1, high);
        }

        return;
}
        const int MAX_LENGTH = 200;
        int main()
        {
                int size = 0;
                int ArraySize;
                ArraySize = 0;
                ifstream inFile;
                int low;
                low = 0;
                int high;
                high=0;
                int NumArray[MAX_LENGTH]= {'0'};
                inFile.open("input.txt");

 //Loop reads the inputed array of integers to be sorted
 //Checks for errors in input based on length
                for (ArraySize = 0; ArraySize < MAX_LENGTH; ArraySize++)
                {
                    inFile >> NumArray[ArraySize];
                    if ( inFile.eof()||size > MAX_LENGTH)
                    {
                        break;
                    }
                    size++;

                }




                high = size-1;

         //All the previous functions only had two inputs but three were requuired
                print_array(NumArray, low, high);
                quick_sort(NumArray, low, high);
                print_array(NumArray, low, high);
                return 0;
        }//end of main


