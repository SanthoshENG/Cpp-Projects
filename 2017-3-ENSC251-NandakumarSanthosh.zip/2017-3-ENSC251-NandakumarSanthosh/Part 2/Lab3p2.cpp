// I declare that this assignment is my own work and that I have correctly acknowledged the
// work of others. I acknowledged that I have read and followed the Academic Honesty and
// Integrity related policies as outlined in the syllabus.
//
// Santhosh Nandakumar  September 29, 2017
//
// 301300261

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

//Value that terminates the program
const int TERMINAL_VALUE = -1;

int main()
{
    
    vector <int> Grades;  //vector storing inputed grades
    int Input = 0;        //Variable used to input grades into the vector if it is a valid grade
    int SizeGrades = 0;   //Stores the size of the Grade vector
    int InitialCount = 1; //Used to count the number of each grade 
    int integer = 0;      //Counter in loops
    
    cout << "Enter the student's grades here:" << endl;
    
    //Checks the input and stores all valid inputs into the Grades vector
    for (unsigned int integer = 0; integer<=Grades.size(); integer++)
    {
        cin>>Input;
        //cout << endl;
        
        if (Input < TERMINAL_VALUE)
        {
            
        }
        if (Input == TERMINAL_VALUE)
        {
            break;
        }
        else
        {
           Grades.push_back(Input); 
        }
    }
    
    //Sorts the Grade vector in ascending order
    sort(Grades.begin(),Grades.end());
     
    //Finds the size of the Grades vector to be used in the dynamic array
    SizeGrades = Grades.size();
    
    //Initializes Dynamic array here because proper size is required
    int *DynamicGrades = NULL;
    DynamicGrades = new int [SizeGrades];
    
//Loop that checks if multiple grades were stored in the vector
//Prints out the if multiple grades are entered in ascending order
for ( integer = 0; integer < SizeGrades; integer++)
{
        InitialCount = 1;
        while (Grades[integer] == Grades[integer+1])
        {
            integer++;
            InitialCount++;
        }
    if (Grades[integer] < 0)
    {
        
    }
    else
    {
        cout << "Number of "<< Grades[integer] << "'s: " << InitialCount << endl;    
    }
}
    
    //Transfers the Grades from the vector to dynmanic memory
    for (integer = 0; integer < SizeGrades; integer++)
    {
        DynamicGrades[integer] = Grades[integer];
    }
    
    //Deletes the dynamic memory
    delete[] DynamicGrades;
    return 0;
    
}