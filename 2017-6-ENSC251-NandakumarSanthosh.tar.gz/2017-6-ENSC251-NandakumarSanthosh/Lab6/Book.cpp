#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
#include <fstream>
using namespace std;
#include "Book.h"

Book::Book()
{
    title;
    author;
    pubDate;
}
Book::Book(string btitle, string bauthor, string date)
{
    title = btitle;
    author = bauthor;
    pubDate = date;

}

string Book::getTitle() const
{
   return title;

}
string Book::getAuthor() const
{

    return author;

}
string Book::getDateOfPub() const
{

    return pubDate;

}
void Book::setTitle(string newTitle)
{
    title = newTitle;
}
void Book::setAuthor(string newAuthor)
{
    author = newAuthor;
}
void Book::setDateOfPub(string newDate)
{
    pubDate = newDate;
}
ostream& operator <<(ostream& outs, const Book& myBook)
{
    string myTitle = myBook.getTitle();
    string myAuthor = myBook.getAuthor();
    string myDate = myBook.getDateOfPub();

    outs << myAuthor << ". " << myTitle << ". " << myDate << endl;
    return outs;

}
bool operator < (const Book& book1, const Book& book2)
{
    return (book1.author < book2.author);
}
