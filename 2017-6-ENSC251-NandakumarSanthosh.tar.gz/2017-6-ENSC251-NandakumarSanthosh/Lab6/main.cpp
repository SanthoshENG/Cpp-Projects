#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
#include <fstream>
#include "Book.h"
using namespace std;



int main()
{
  char option;
  string theTitle;
  string theAuthor;
  string theDate;

  vector <Book> myBooks; //vector of books

//Loop which acts a menu of options
//Can either add a new book
//Print the list of books
//Or quit the program
do
{
  cout << "Select from the following choices:" << endl;
  cout << "1. Add new book" << endl;
  cout << "2. Print listing book" << endl;
  cout << "3. Quit" << endl;

  cin>> option;

 if (option == '1')
 {
    cout << "Enter title:"<< endl;
    cin.ignore();
    getline(cin,theTitle);

    //Checks if title was entered
    if(theTitle.size()==0)
    {
    	cout << "Error a title was not entered, Try Again"<<endl;
    	continue;
    }

    cout << "Enter author:" << endl;
    getline(cin,theAuthor);

    //Checks if author was entered
    if(theAuthor.size()==0)
    {
    	cout << "Error an author was not entered, Try Again"<<endl;
    	continue;
    }

    cout << "Enter date:" << endl;
    getline(cin,theDate);

    //Checks if the date was entered properly
    if(theDate.size()== 0)
    {
    	cout << "Error a date was not entered, Try Again"<<endl;
    	continue;
    }
    else if(theDate.size()!= 4)
    {
        cout << "Error in date entry, Try Again"<<endl;
      	continue;
    }

    else if(theDate.size() == 4)
    {
    	for ( int i = 0 ; i < theDate.size() ; i++)
    	{
    		if ( !isdigit(theDate[i]) )
    		{
    			cout << "Error in date entry, Try Again"<<endl;
    			break;

    		}

    	}

    }

    Book newBook(theTitle,theAuthor,theDate);
    myBooks.push_back(newBook);
 }
 else if (option == '2')
 {

     if (myBooks.empty())
     {
         cout << "Error. You have not entered any books, make another selection" << endl;
         continue;
     }
     else
     {
        cout << "The books entered so far, sorted alphabetically by author are:" << endl;
        //Sorts the list of authors of each book alphabetically before printing
        sort(myBooks.begin(), myBooks.end());
        //Prints the list of books in the vector myBooks
        for (unsigned int i = 0; i < myBooks.size(); i++)
        {
            cout << myBooks[i];
        }


     }
 }
 else if(option == '3')
  {
      cout << "Quiting program" << endl;
  }

 //Error checking on the option chosen by user
 if (option != '1' && option != '2' && option != '3')
  {
    cout << "Error! You entered an invalid option. Try Again" << endl;
    option = '1';
    continue;

  }

}while( option == '1' || option == '2');

return 0;
}







