

#include <iostream>
#include <string>
#include <vector>
using namespace std;
#ifndef BOOK_H
#define BOOK_H


class Book
{
    public:


    /**
    * @brief Default Constructor
    * @preCondition: None
    * @param: None
    * @postCondition: An object of type Book is intialized with
    * empty title, author and publucation date
    * @return: None
    */
    Book();

    /**
    * @brief Overloaded Constructor
    * @preCondition: None
    * @param: title, author, date of publication
    * all of type string
    * @postCondition: An object of type Book is intialized with
    * the user entered title, author and publucation date
    * @return: None
    */
    Book(string btitle, string bauthor, string date);


    /**
    * @brief Accesses the Title of the book
    * @preCondition: An object of type book must exist
    * with correct initializations
    * @param: None
    * @postCondition: The title of the book is returned
    * @return: string
    */
    string getTitle() const;

     /**
    * @brief Accesses the Author of the book
    * @preCondition: An object of type book must exist
    * with correct initializations
    * @param: None
    * @postCondition: The author of the book is returned
    * @return: string
    */
    string getAuthor() const;

    /**
    * @brief Accesses the Title of the book
    * @preCondition: An object of type book must exist
    * with correct initializations
    * @param: None
    * @postCondition: The title of the book is returned
    * @return: string
    */
    string getDateOfPub() const;


    /**
    * @brief Mutator: sets the Title of the book
    * @preCondition: An object of type book must exist
    * with correct initializations
    * @param: the Title of book of type string
    * @postCondition: The title of the book is set based
    * on user input
    * @return: void
    */
    void setTitle(string newTitle);

    /**
    * @brief Mutator: sets the Author of the book
    * @preCondition: An object of type book must exist
    * with correct initializations
    * @param: the Author of book of type string
    * @postCondition: The Author of the book is set based
    * on user input
    * @return: void
    */
    void setAuthor(string newAuthor);


    /**
    * @brief Mutator: sets the Date of Publication of the book
    * @preCondition: An object of type book must exist
    * with correct initializations
    * @param: the date of publication of the book of type string
    * @postCondition: The Date of Publication of the book is set based
    * on user input
    * @return: void
    */
    void setDateOfPub(string newDate);


    /**
    * @brief overloaded << operator allows user to print the object
    * of type Book
    * @preCondition: An object of type book must exist
    * with correct initializations
    * @param: variable of type ostream from fstream library on left side
    * of << and an object of type book on the right side
    * @postCondition: The object of type Book is printed
    * @return: none
    */
    friend ostream& operator <<(ostream& outs, const Book& myBook);


    /**
    * @brief overloaded < operator to compare two members in
    * in two different objects of type Book
    * @preCondition: Two objects of type book must exist
    * with correct initializations
    * @param: two objects of type Book
    * @postCondition: The author names between two books is checked to
    * see if they are in alphabetical order
    * @return: boolean true or false
    */
    friend bool operator < (const Book& book1, const Book& book2);

    private:

    string title; //stores title of book
    string author; // stores authors name in last, first format
    string pubDate; //stores the date the book was published
};

#endif
