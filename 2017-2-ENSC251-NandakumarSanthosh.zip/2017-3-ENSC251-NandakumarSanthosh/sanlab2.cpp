// I declare that this assignment is my own work and that I have correctly acknowledged the
// work of others. I acknowledged that I have read and followed the Academic Honesty and
// Integrity related policies as outlined in the syllabus.
//
// Santhosh Nandakumar  Sept 22, 2017
//
// 301300261
// Purpose of this code is to convert an English name into Pig Latin

#include <iostream>
#include <string>
#include <stdio.h>
#include <ctype.h>

using namespace std;

//Global Constants used to convert English names into Pig Latiin
//Rules of Pig Latin
//If the first letter is a consonant, move it to the end and add ay to the end.
//If the first letter is a vowel, add way to the end.

const string WAY = "way";
const string AY  = "ay";

//Converts uppercase letters to lower case letters
string UpperToLower(string Name);

//Checks if the first character is a vowel
bool CheckVowel( string Name );

//Adds ay or way to convert the name based on the rules given above
string Add_ay_way( string Name );

//Converts the first letter of a name to a capital letter
string LowerToUpper ( string Name );

//Used for error checking of the name
bool CheckAlphabet ( string Name );


int main()
{

string FirstName = "0";
string LastName = "0";
string LowerFirstName = "0";
string LowerLastName = "0";
string FinalFirstName = "0";
string FinalLastName = "0";
string FinalName = "0";

//Checks for errors in user input of first name
do
{
	cout<<"Enter your first name"<<endl;
	cin>>FirstName;

	if (CheckAlphabet(FirstName)==0)
	{
		cout <<endl <<"Your name should only contain letters"<<endl;
		cout << "Please try again"<<endl<<endl;
	}
}
while(CheckAlphabet(FirstName)==0);

//Checks for errors in user input of last name
do
{
	cout<<"Enter your last name"<<endl;
	cin>>LastName;

	if (CheckAlphabet(LastName)==0)
	{
		cout <<endl <<"Your name should only contain letters"<<endl;
		cout << "Please try again"<<endl<<endl;
	}
}
while(CheckAlphabet(LastName)==0);

	LowerFirstName = UpperToLower(FirstName);
	LowerLastName = UpperToLower(LastName);

	cout << endl << "Your name in Pig Latin is" <<endl;

	FinalFirstName = LowerToUpper(Add_ay_way(LowerFirstName));
	FinalLastName = LowerToUpper(Add_ay_way(LowerLastName));
	FinalName = FinalFirstName.append(" " + FinalLastName);
	cout << FinalName;

	return 0;
}

string UpperToLower(string Name)
{
    int NameSize = Name.size();

    for (int index = 0; index < NameSize; index++) // This part of the CODE converts all UPPERCASE to LOWERCASE, but not vice-versa (First name)
    {
    	if (islower(Name[index]))
    	{
    		continue;
    	}

    	else
    	{
    		Name[index] = tolower(Name[index]);
    	}
    }
    return Name;
}

bool CheckVowel( string Name )
{
    if ( Name[0] == 'a' || Name[0] == 'e' || Name[0] == 'i'  || Name[0] == 'o' || Name[0] ==  'u' )
    {
        return 1;
    }

    else
    {
        return 0;
    }
}

string Add_ay_way( string Name )
{
    string FinalName  = "0" ;

    if ( CheckVowel(Name) == 1 )
    {
        string temp = WAY;
        FinalName = Name.append(temp);
        temp = FinalName ;

        return temp ;
    }

    else
    {
        string NameCopy = Name ;
        string DelName = "0" ;

        DelName = NameCopy.erase(0,1);
        FinalName = DelName.append(Name[0]+AY);

        return FinalName;
    }
}

string LowerToUpper ( string Name )
{
    Name[0] = toupper(Name[0]);
    return Name ;
}


bool CheckAlphabet ( string Name )
{
	int i ;
	int LengthString = 0 ;
	LengthString = Name.size();


	for ( i = 0 ; i < LengthString ; i++ )
	{
		if ( (isalpha(Name[i])) )
		{
			if ( i == (LengthString-1) )
			{
				return true ;
			}

			continue ;
		}

		else
		{
			return false ;
		}
	}
}



